package com.example;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NewTest {
	WebDriver wd=null;
	long startTime;
	@BeforeTest
	public void intiate() {
		
		System.out.println("config intiated on chrome");
		// Example for chrome browser
		//register the webdriver =>browser vendor 
		WebDriverManager.chromedriver().setup();
		//creating an object to the object
		wd=new ChromeDriver();
		//maximize the browser
		wd.manage().window().maximize();
		// Set the page load timeout
		//wd.manage().timeouts().pageLoadTimeout(5000,TimeUnit.MILLISECONDS);
		
//		System.out.println("config intiated on edge");
//		// Example for edge browser
//		//register the webdriver =>browser vendor 
//		WebDriverManager.edgedriver().setup();
//		//creating an object to the object
//		wd=new EdgeDriver();
//		//maximize the browser
//		wd.manage().window().maximize();
//		// Set the page load timeout
//		wd.manage().timeouts().pageLoadTimeout(5000,TimeUnit.MILLISECONDS);

	}

	@Test(priority = 1)
	public void testurl() {
		System.out.println("test intiated: mAadhar_App");
		startTime = System.currentTimeMillis(); // Capturing start time

		//url naviagte
		wd.get("http://localhost:4200/home");

		//admin
		wd.findElement(By.xpath("/html/body/app-root/app-homepage/div/h3[1]/a[2]")).click();
		wd.findElement(By.xpath("//*[@id=\"adminLogin\"]")).sendKeys("987123987144");
		wd.findElement(By.xpath("//*[@id=\"adminPassword\"]")).sendKeys("Admi@1234");
		wd.findElement(By.xpath("//*[@id=\"adminLoginSubmit\"]/button")).click();
		wd.findElement(By.xpath("/html/body/app-root/app-admin-dasboard/div/button[2]")).click();
		wd.findElement(By.xpath("//*[@id=\"signoutUser\"]")).click();
		//System.out.println("admin test completed");

		//user
		wd.findElement(By.xpath("/html/body/app-root/app-admin-login/div/div/div/form/div[5]/button")).click();
		wd.findElement(By.xpath("/html/body/app-root/app-user-login/div/div/div/form/div[1]/input")).sendKeys("20240117130337");
		wd.findElement(By.xpath("/html/body/app-root/app-user-login/div/div/div/form/div[2]/input")).sendKeys("4442227890");
		wd.findElement(By.xpath("//*[@id=\"userLoginSubmit\"]")).click();
		wd.findElement(By.xpath("/html/body/app-root/app-user-dasboard/div/div/div/form/button[3]")).click();
		wd.findElement(By.xpath("/html/body/app-root/app-view-citizen/div/table/tbody/tr/td[7]/button")).click();
		wd.findElement(By.xpath("//*[@id=\"signoutUser\"]")).click();
		//System.out.println("user test completed");
		
		System.out.println("test completed");

	}

	@AfterTest
	public void  derefer() {
		System.out.println("wd closed");
		wd.close();
	}


}