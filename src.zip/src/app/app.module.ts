import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { HomepageComponent } from './homepage/homepage.component';
import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';
import { UserDasboardComponent } from './user-dasboard/user-dasboard.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminDasboardComponent } from './admin-dasboard/admin-dasboard.component';
import { ViewCitizenComponent } from './view-citizen/view-citizen.component';
import { UpdateComponent } from './update/update.component';
import { IssuedComponent } from './issued/issued.component';



const routes: Routes = [
  {path:" ",component:AppComponent},
  {path:"home",component:HomepageComponent},
  {path: 'AadharApp/citizens/signUp',pathMatch: 'full',component: UserSignUpComponent},
  {path: 'AadharApp/citizens/dashboard',pathMatch: 'full',component: UserDasboardComponent},
  {path: 'AadharApp/citizens/logIn',pathMatch: 'full',component: UserLoginComponent},
  {path: 'AadharApp/admin/logIn',pathMatch: 'full',component: AdminLoginComponent},
  {path: 'AadharApp/admin/dashboard',pathMatch: 'full',component: AdminDasboardComponent},
  {path: 'AadharApp/citizens/view',pathMatch: 'full',component: ViewCitizenComponent},
  {path: 'AadharApp/citizens/update',pathMatch: 'full',component: UpdateComponent},
  {path: 'AadharApp/admin/issued',pathMatch: 'full',component: IssuedComponent}


  ];
  
@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    UserSignUpComponent,
    UserDasboardComponent,
    UserLoginComponent,
    AdminLoginComponent,
    AdminDasboardComponent,
    ViewCitizenComponent,
    UpdateComponent,
    IssuedComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)

  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
