import { Component } from '@angular/core';

@Component({
  selector: 'app-view-citizen',
  templateUrl: './view-citizen.component.html',
  styleUrl: './view-citizen.component.css'
})
export class ViewCitizenComponent {

}
