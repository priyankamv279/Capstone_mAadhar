import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-dasboard',
  templateUrl: './admin-dasboard.component.html',
  styleUrls: ['./admin-dasboard.component.css']
})
export class AdminDasboardComponent {

  constructor(private router: Router) {}

  signOut(): void {
    localStorage.clear();
    this.router.navigate(['AadharApp/admin/logIn']);
  }

  approveApplication(applicationId: number): void {
    // Perform any additional logic if needed
    alert(`Application ${applicationId} has been approved.`);
    this.router.navigate(['AadharApp/admin/issued']);

  }
}

