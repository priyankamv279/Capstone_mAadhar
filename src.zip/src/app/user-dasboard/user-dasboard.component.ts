import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-dasboard',
  templateUrl: './user-dasboard.component.html',
  styleUrls: ['./user-dasboard.component.css'],
})
export class UserDasboardComponent implements OnInit {
  aadharApplicationForm: FormGroup;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.aadharApplicationForm = this.formBuilder.group({
      citizenId: ['', Validators.required],  // Added citizenId field
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', Validators.required],
      gender: ['', Validators.required],
      address: ['', Validators.required],
      passportId: ['', Validators.required],
    });
  }

  get f() {
    return this.aadharApplicationForm.controls;
  }

  onApply(): void {
    this.submitted = true;
    if (this.aadharApplicationForm.invalid) {
      return;
    }

    // Your logic to handle the Aadhar application submission
    console.log('Aadhar Application Submitted:', this.aadharApplicationForm.value);
    alert('Aadhar application submitted successfully!');

  }

  signOut(): void {
    localStorage.clear();
    this.router.navigate(['AadharApp/citizens/logIn']);
  }
}
