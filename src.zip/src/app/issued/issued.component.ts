import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-issued',
  templateUrl: './issued.component.html',
  styleUrl: './issued.component.css'
})
export class IssuedComponent {
  constructor(private router: Router) {}

  signOut(): void {
    localStorage.clear();
    this.router.navigate(['AadharApp/admin/logIn']);
  }
}
