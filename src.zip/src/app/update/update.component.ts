import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrl: './update.component.css'
})
export class UpdateComponent implements OnInit {
  aadharApplicationForm: FormGroup;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.aadharApplicationForm = this.formBuilder.group({
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', Validators.required],
      gender: ['', Validators.required],
      address: ['', Validators.required],
      passportId: ['', Validators.required],
    });
  }

  get f() {
    return this.aadharApplicationForm.controls;
  }

  onApply(): void {
    this.submitted = true;
    if (this.aadharApplicationForm.invalid) {
      return;
    }

    // Your logic to handle the Aadhar application submission
    console.log('Aadhar Application Submitted:', this.aadharApplicationForm.value);
    alert('Aadhar updated successfully!');

  }

  signOut(): void {
    localStorage.clear();
    this.router.navigate(['AadharApp/citizens/logIn']);
  }
}

