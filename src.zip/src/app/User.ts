export class User{

    userFullName: string;
    email:string;
    gender:string;
    address:string;
    mobile:string;
    issueDate:string;
    citizenId:string;
    aadharApplied:boolean;
    passportId:string;
    
}